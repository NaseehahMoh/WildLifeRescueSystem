public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(
            String rescueCaseID,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String currentRescueStatus,
            String injuryDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        super(
                rescueCaseID,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost,
                currentRescueStatus
        );

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = getNumberOfRescueDays()
                * getDailyCareCost();

        total += veterinaryTreatmentCost;

        if (surgeryRequired) {
            total += 5000;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (surgeryRequired) {
            return "Critical";
        }

        if (veterinaryTreatmentCost >= 5000) {
            return "High";
        }

        return "Medium";
    }

    @Override
    public void displaySpecificInformation() {

        System.out.println(
                "Injury Description: " + injuryDescription);

        System.out.println(
                "Veterinary Treatment Cost: R"
                        + veterinaryTreatmentCost);

        System.out.println(
                "Surgery Required: "
                        + (surgeryRequired ? "Yes" : "No"));
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }
}