public interface RescueOperations {

    void startRescue();

    void completeRescue();

    void generateSummary();
}