import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static WildlifeRescueSystem system =
            new WildlifeRescueSystem();

    public static void main(String[] args) {

        int choice;

        do {
            displayMenu();

            choice = getInt("Enter your choice: ");

            switch (choice) {

                case 1:
                    createRescueCase();
                    break;

                case 2:
                    searchRescueCase();
                    break;

                case 3:
                    updateRescueStatus();
                    break;

                case 4:
                    system.displayAllCases();
                    break;

                case 5:
                    system.generateReport();
                    break;

                case 6:
                    System.out.println(
                            "Thank you for using the Wildlife Rescue System.");
                    break;

                default:
                    System.out.println(
                            "Invalid choice. Please try again.");
            }

        } while (choice != 6);

        scanner.close();
    }

    public static void displayMenu() {

        System.out.println();
        System.out.println("======================================");
        System.out.println("      WILDLIFE RESCUE SYSTEM");
        System.out.println("======================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Generate Rescue Report");
        System.out.println("6. Exit");
        System.out.println("======================================");
    }

    public static void createRescueCase() {

        System.out.println();
        System.out.println("===== CREATE RESCUE CASE =====");

        String caseID =
                getNonEmptyString("Enter Case ID: ");

        if (system.searchRescueCase(caseID) != null) {

            System.out.println(
                    "That Case ID already exists.");

            return;
        }

        String animalName =
                getNonEmptyString("Enter Animal Name: ");

        String species =
                getNonEmptyString("Enter Species: ");

        String location =
                getNonEmptyString("Enter Rescue Location: ");

        String ranger =
                getNonEmptyString("Enter Assigned Ranger: ");

        int days =
                getPositiveInt("Enter Number of Rescue Days: ");

        double dailyCost =
                getPositiveDouble("Enter Daily Care Cost: ");

        System.out.println();
        System.out.println("Select Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int type = getInt("Enter type: ");

        RescueCase rescueCase;

        switch (type) {

            case 1:

                String injury =
                        getNonEmptyString(
                                "Enter Injury Description: ");

                double veterinaryCost =
                        getPositiveDouble(
                                "Enter Veterinary Treatment Cost: ");

                boolean surgery =
                        getYesNo(
                                "Is Surgery Required? (Y/N): ");

                rescueCase =
                        new InjuredAnimalRescue(
                                caseID,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                "Under Observation",
                                injury,
                                veterinaryCost,
                                surgery
                        );

                break;

            case 2:

                int age =
                        getPositiveInt(
                                "Enter Estimated Age in Months: ");

                double feedingCost =
                        getPositiveDouble(
                                "Enter Feeding Cost: ");

                boolean foster =
                        getYesNo(
                                "Is Foster Care Required? (Y/N): ");

                rescueCase =
                        new OrphanedAnimalRescue(
                                caseID,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                "Under Observation",
                                age,
                                feedingCost,
                                foster
                        );

                break;

            case 3:

                String classification =
                        getNonEmptyString(
                                "Enter Conservation Classification: ");

                double securityCost =
                        getPositiveDouble(
                                "Enter Security Cost: ");

                boolean specialist =
                        getYesNo(
                                "Is Specialist Team Required? (Y/N): ");

                rescueCase =
                        new EndangeredSpeciesRescue(
                                caseID,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                "Under Observation",
                                classification,
                                securityCost,
                                specialist
                        );

                break;

            default:

                System.out.println(
                        "Invalid rescue type.");

                return;
        }

        if (system.addRescueCase(rescueCase)) {

            System.out.println(
                    "Rescue case added successfully.");

        } else {

            System.out.println(
                    "Could not add rescue case.");
        }
    }

    public static void searchRescueCase() {

        System.out.println();

        String caseID =
                getNonEmptyString(
                        "Enter Case ID to search: ");

        RescueCase rescueCase =
                system.searchRescueCase(caseID);

        if (rescueCase == null) {

            System.out.println(
                    "Rescue case not found.");

            return;
        }

        System.out.println();
        System.out.println("===== RESCUE CASE =====");

        System.out.println(
                "Case ID: "
                        + rescueCase.getRescueCaseID());

        System.out.println(
                "Animal: "
                        + rescueCase.getAnimalName());

        System.out.println(
                "Species: "
                        + rescueCase.getSpecies());

        System.out.println(
                "Location: "
                        + rescueCase.getRescueLocation());

        System.out.println(
                "Ranger: "
                        + rescueCase.getAssignedRanger());

        System.out.println(
                "Type: "
                        + rescueCase.getRescueType());

        System.out.println(
                "Priority: "
                        + rescueCase.determinePriority());

        System.out.println(
                "Status: "
                        + rescueCase.getCurrentRescueStatus());

        System.out.printf(
                "Total Cost: R%.2f%n",
                rescueCase.calculateTotalRescueCost());

        rescueCase.displaySpecificInformation();
    }

    public static void updateRescueStatus() {

        String caseID =
                getNonEmptyString(
                        "Enter Case ID: ");

        RescueCase rescueCase =
                system.searchRescueCase(caseID);

        if (rescueCase == null) {

            System.out.println(
                    "Rescue case not found.");

            return;
        }

        System.out.println();
        System.out.println("1. Start Rescue");
        System.out.println("2. Complete Rescue");
        System.out.println("3. Enter Custom Status");

        int choice =
                getInt("Enter choice: ");

        switch (choice) {

            case 1:

                rescueCase.startRescue();

                System.out.println(
                        "Rescue started.");

                break;

            case 2:

                rescueCase.completeRescue();

                System.out.println(
                        "Rescue completed.");

                break;

            case 3:

                String status =
                        getNonEmptyString(
                                "Enter new status: ");

                rescueCase.setCurrentRescueStatus(status);

                System.out.println(
                        "Status updated.");

                break;

            default:

                System.out.println(
                        "Invalid choice.");
        }
    }

    // =========================
    // INPUT VALIDATION
    // =========================

    public static String getNonEmptyString(
            String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println(
                    "Input cannot be empty.");
        }
    }

    public static int getInt(String message) {

        while (true) {

            try {

                System.out.print(message);

                return Integer.parseInt(
                        scanner.nextLine().trim());

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid whole number.");
            }
        }
    }

    public static int getPositiveInt(
            String message) {

        while (true) {

            int value = getInt(message);

            if (value > 0) {
                return value;
            }

            System.out.println(
                    "Number must be greater than 0.");
        }
    }

    public static double getPositiveDouble(
            String message) {

        while (true) {

            try {

                System.out.print(message);

                double value =
                        Double.parseDouble(
                                scanner.nextLine().trim());

                if (value > 0) {
                    return value;
                }

                System.out.println(
                        "Amount must be greater than 0.");

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid amount.");
            }
        }
    }

    public static boolean getYesNo(
            String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim();

            if (input.equalsIgnoreCase("Y")) {
                return true;
            }

            if (input.equalsIgnoreCase("N")) {
                return false;
            }

            System.out.println(
                    "Please enter Y or N.");
        }
    }
}
               