public class WildlifeRescueSystemTest {
    

public static void main(String[] args) {

        testAddRescueCase();
        testSearchRescueCase();
        testUpdateRescueStatus();
        testCalculateRescueCost();

        System.out.println();
        System.out.println("=================================");
        System.out.println("ALL UNIT TESTS COMPLETED");
        System.out.println("=================================");
    }

    // Test adding a rescue case
    public static void testAddRescueCase() {

        WildlifeRescueSystem system =
                new WildlifeRescueSystem();

        RescueCase rescue =
                new InjuredAnimalRescue(
                        "T001",
                        "Leo",
                        "Lion",
                        "Durban",
                        "John",
                        3,
                        500,
                        "Under Observation",
                        "Broken leg",
                        3000,
                        false
                );

        boolean result =
                system.addRescueCase(rescue);

        if (result) {
            System.out.println(
                    "PASS: Add rescue case");
        } else {
            System.out.println(
                    "FAIL: Add rescue case");
        }
    }

    // Test searching for a rescue case
    public static void testSearchRescueCase() {

        WildlifeRescueSystem system =
                new WildlifeRescueSystem();

        RescueCase rescue =
                new InjuredAnimalRescue(
                        "T002",
                        "Simba",
                        "Lion",
                        "Durban",
                        "Sarah",
                        2,
                        400,
                        "Under Observation",
                        "Leg injury",
                        2000,
                        false
                );

        system.addRescueCase(rescue);

        RescueCase found =
                system.searchRescueCase("T002");

        if (found != null) {
            System.out.println(
                    "PASS: Search rescue case");
        } else {
            System.out.println(
                    "FAIL: Search rescue case");
        }
    }

    // Test updating rescue status
    public static void testUpdateRescueStatus() {

        WildlifeRescueSystem system =
                new WildlifeRescueSystem();

        RescueCase rescue =
                new InjuredAnimalRescue(
                        "T003",
                        "Max",
                        "Elephant",
                        "Kruger",
                        "David",
                        4,
                        600,
                        "Under Observation",
                        "Foot injury",
                        1500,
                        false
                );

        system.addRescueCase(rescue);

        rescue.startRescue();

        if (rescue.getCurrentRescueStatus()
                .equals("Rescue In Progress")) {

            System.out.println(
                    "PASS: Start rescue");
        } else {

            System.out.println(
                    "FAIL: Start rescue");
        }

        rescue.completeRescue();

        if (rescue.getCurrentRescueStatus()
                .equals("Completed")) {

            System.out.println(
                    "PASS: Complete rescue");
        } else {

            System.out.println(
                    "FAIL: Complete rescue");
        }
    }

    // Test rescue cost calculation
    public static void testCalculateRescueCost() {

        RescueCase rescue =
                new InjuredAnimalRescue(
                        "T004",
                        "Bella",
                        "Lion",
                        "Pretoria",
                        "Mike",
                        3,
                        500,
                        "Under Observation",
                        "Minor injury",
                        3000,
                        false
                );

        double expectedCost = 4500;

        double actualCost =
                rescue.calculateTotalRescueCost();

        if (actualCost == expectedCost) {

            System.out.println(
                    "PASS: Calculate rescue cost");

        } else {

            System.out.println(
                    "FAIL: Calculate rescue cost");

            System.out.println(
                    "Expected: R" + expectedCost);

            System.out.println(
                    "Actual: R" + actualCost);
        }
    }
}