public abstract class RescueCase implements RescueOperations {

    private String rescueCaseID;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    public RescueCase(
            String rescueCaseID,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String currentRescueStatus) {

        this.rescueCaseID = rescueCaseID;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = currentRescueStatus;
    }

    public String getRescueCaseID() {
        return rescueCaseID;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return currentRescueStatus;
    }

    public void setCurrentRescueStatus(String status) {
        this.currentRescueStatus = status;
    }

    public abstract double calculateTotalRescueCost();

    public abstract String determinePriority();

    public abstract void displaySpecificInformation();

    public abstract String getRescueType();

    @Override
    public void startRescue() {
        currentRescueStatus = "Rescue In Progress";
    }

    @Override
    public void completeRescue() {
        currentRescueStatus = "Completed";
    }

    @Override
    public void generateSummary() {
        System.out.println("Case ID: " + rescueCaseID);
        System.out.println("Rescue Type: " + getRescueType());
        System.out.println("Species: " + species);
        System.out.println("Assigned Ranger: " + assignedRanger);
        System.out.println("Priority: " + determinePriority());
        System.out.println("Current Status: " + currentRescueStatus);
        System.out.printf("Total Rescue Cost: R%.2f%n",
                calculateTotalRescueCost());
    }
}