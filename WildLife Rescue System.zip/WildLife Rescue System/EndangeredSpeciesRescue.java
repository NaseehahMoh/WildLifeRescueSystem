public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(
            String rescueCaseID,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String currentRescueStatus,
            String conservationClassification,
            double securityCost,
            boolean specialistTeamRequired) {

        super(
                rescueCaseID,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost,
                currentRescueStatus
        );

        this.conservationClassification =
                conservationClassification;

        this.securityCost = securityCost;
        this.specialistTeamRequired =
                specialistTeamRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = getNumberOfRescueDays()
                * getDailyCareCost();

        total += securityCost;

        if (specialistTeamRequired) {
            total += 8000;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (specialistTeamRequired) {
            return "Critical";
        }

        if (conservationClassification
                .equalsIgnoreCase("Critically Endangered")) {
            return "Critical";
        }

        if (conservationClassification
                .equalsIgnoreCase("Endangered")) {
            return "High";
        }

        return "Medium";
    }

    @Override
    public void displaySpecificInformation() {

        System.out.println(
                "Conservation Classification: "
                        + conservationClassification);

        System.out.println(
                "Security Cost: R" + securityCost);

        System.out.println(
                "Specialist Team Required: "
                        + (specialistTeamRequired
                        ? "Yes" : "No"));
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }
}
