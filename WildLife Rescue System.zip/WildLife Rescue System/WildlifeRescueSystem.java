import java.util.ArrayList;

public class WildlifeRescueSystem {

    private ArrayList<RescueCase> rescueCases;

    public WildlifeRescueSystem() {
        rescueCases = new ArrayList<>();
    }

    // Add a new rescue case
    public boolean addRescueCase(RescueCase rescueCase) {

        if (searchRescueCase(rescueCase.getRescueCaseID()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    // Search for a rescue case
    public RescueCase searchRescueCase(String caseID) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getRescueCaseID()
                    .equalsIgnoreCase(caseID)) {

                return rescueCase;
            }
        }

        return null;
    }

    // Update rescue status
    public boolean updateRescueStatus(
            String caseID,
            String newStatus) {

        RescueCase rescueCase =
                searchRescueCase(caseID);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.setCurrentRescueStatus(newStatus);

        return true;
    }

    // Display all rescue cases
    public void displayAllCases() {

        if (rescueCases.isEmpty()) {
            System.out.println(
                    "No rescue cases found.");
            return;
        }

        for (RescueCase rescueCase : rescueCases) {

            System.out.println();
            System.out.println(
                    "================================");

            System.out.println(
                    "Case ID: "
                            + rescueCase.getRescueCaseID());

            System.out.println(
                    "Animal: "
                            + rescueCase.getAnimalName());

            System.out.println(
                    "Species: "
                            + rescueCase.getSpecies());

            System.out.println(
                    "Location: "
                            + rescueCase.getRescueLocation());

            System.out.println(
                    "Ranger: "
                            + rescueCase.getAssignedRanger());

            System.out.println(
                    "Rescue Type: "
                            + rescueCase.getRescueType());

            System.out.println(
                    "Priority: "
                            + rescueCase.determinePriority());

            System.out.println(
                    "Status: "
                            + rescueCase.getCurrentRescueStatus());

            System.out.printf(
                    "Total Cost: R%.2f%n",
                    rescueCase.calculateTotalRescueCost());

            rescueCase.displaySpecificInformation();

            System.out.println(
                    "================================");
        }
    }

    // Generate final report
    public void generateReport() {

        double totalCost = 0;

        System.out.println();
        System.out.println(
                "========================================");
        System.out.println(
                "       WILDLIFE RESCUE REPORT");
        System.out.println(
                "========================================");

        for (RescueCase rescueCase : rescueCases) {

            double cost =
                    rescueCase.calculateTotalRescueCost();

            totalCost += cost;

            System.out.println(
                    "Case ID: "
                            + rescueCase.getRescueCaseID());

            System.out.println(
                    "Animal: "
                            + rescueCase.getAnimalName());

            System.out.println(
                    "Species: "
                            + rescueCase.getSpecies());

            System.out.println(
                    "Type: "
                            + rescueCase.getRescueType());

            System.out.println(
                    "Priority: "
                            + rescueCase.determinePriority());

            System.out.println(
                    "Status: "
                            + rescueCase.getCurrentRescueStatus());

            System.out.printf(
                    "Cost: R%.2f%n",
                    cost);

            System.out.println(
                    "----------------------------------------");
        }

        System.out.println(
                "Total Cases: " + rescueCases.size());

        System.out.printf(
                "Total Rescue Cost: R%.2f%n",
                totalCost);

        System.out.println(
                "========================================");
    }
}


    