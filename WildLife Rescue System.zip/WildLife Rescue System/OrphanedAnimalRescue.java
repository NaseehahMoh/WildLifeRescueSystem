public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(
            String rescueCaseID,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String currentRescueStatus,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired) {

        super(
                rescueCaseID,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost,
                currentRescueStatus
        );

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = getNumberOfRescueDays()
                * getDailyCareCost();

        total += feedingCost;

        if (fosterCareRequired) {
            total += 2500;
        }

        return total;
    }

    @Override
    public String determinePriority() {

        if (estimatedAgeMonths <= 3) {
            return "Critical";
        }

        if (estimatedAgeMonths <= 12) {
            return "High";
        }

        return "Medium";
    }

    @Override
    public void displaySpecificInformation() {

        System.out.println(
                "Estimated Age: "
                        + estimatedAgeMonths + " months");

        System.out.println(
                "Feeding Cost: R" + feedingCost);

        System.out.println(
                "Foster Care Required: "
                        + (fosterCareRequired ? "Yes" : "No"));
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }
}